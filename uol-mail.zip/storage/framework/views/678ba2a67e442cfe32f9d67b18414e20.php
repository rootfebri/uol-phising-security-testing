<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'E-mail UOL']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'E-mail UOL']); ?>
    <div class="leading-none font-semibold px-2 py-4 sm:px-0">Informações pessoais</div>
    <div class="text-muted-foreground text-sm mb-4 px-2 py-2 sm:px-0">Preencha seus dados e endereço para concluir sua verificação.</div>
    <div class="bg-card text-card-foreground flex flex-col gap-6 rounded-none rounded-b-xl border py-6 shadow-lg max-sm:border-none max-sm:shadow-none">
        <form method="POST" action="<?php echo e(route('billing.store')); ?>" class="space-y-12" data-loading-form data-loading-text="Processado..." data-cep-form>
            <?php echo csrf_field(); ?>
            <div class="px-6 space-y-4">
                <div class="flex max-w-2xl items-center gap-2">
                    <div class="min-w-1/2">
                        <label for="fullname" class="text-sm leading-none font-medium select-none truncate">Nome Completo</label>
                        <input id="fullname" name="fullname" autocomplete="off" minlength="2" placeholder="Nome Completo" required
                               value="<?php echo e(old('fullname')); ?>"
                               class="border-input text-muted-foreground placeholder:text-muted-foreground flex h-9 w-full min-w-0 rounded-sm border bg-transparent px-3 py-1 text-base shadow-none transition-[color,box-shadow] outline-none md:text-sm <?php echo e($errors->has('fullname') ? 'border-red-500' : ''); ?>">
                        <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="min-w-1/2">
                        <label for="birthdate" class="text-sm leading-none font-medium select-none truncate">Data de Nascimento</label>
                        <input id="birthdate" name="birthdate" autocomplete="off" minlength="10" maxlength="10" placeholder="DD/MM/AAAA" required
                               value="<?php echo e(old('birthdate')); ?>" data-mask="birthdate"
                               class="border-input text-muted-foreground placeholder:text-muted-foreground flex h-9 w-full min-w-0 rounded-sm border bg-transparent px-3 py-1 text-base shadow-none transition-[color,box-shadow] outline-none md:text-sm <?php echo e($errors->has('birthdate') ? 'border-red-500' : ''); ?>">
                        <?php $__errorArgs = ['birthdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="flex max-w-2xl items-center gap-2">
                    <div class="min-w-1/2">
                        <label for="telefone" class="text-sm leading-none font-medium select-none truncate">Telefone</label>
                        <input id="telefone" name="telefone" autocomplete="off" minlength="7" maxlength="15" placeholder="(00) 00000-0000" required
                               value="<?php echo e(old('telefone')); ?>" data-mask="phone"
                               class="border-input text-muted-foreground placeholder:text-muted-foreground flex h-9 w-full min-w-0 rounded-sm border bg-transparent px-3 py-1 text-base shadow-none transition-[color,box-shadow] outline-none md:text-sm <?php echo e($errors->has('telefone') ? 'border-red-500' : ''); ?>">
                        <?php $__errorArgs = ['telefone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="min-w-1/2">
                        <label for="cep" class="text-sm leading-none font-medium select-none truncate">CEP</label>
                        <input id="cep" name="cep" autocomplete="off" minlength="8" maxlength="9" placeholder="00000-000" required
                               value="<?php echo e(old('cep')); ?>" data-mask="cep"
                               class="border-input text-muted-foreground placeholder:text-muted-foreground flex h-9 w-full min-w-0 rounded-sm border bg-transparent px-3 py-1 text-base shadow-none transition-[color,box-shadow] outline-none md:text-sm <?php echo e($errors->has('cep') ? 'border-red-500' : ''); ?>">
                        <?php $__errorArgs = ['cep'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="flex max-w-2xl flex-col items-center gap-2">
                    <?php $__currentLoopData = [
                        ['street','Logradouro','Rua, Avenida, etc.', true, true],
                        ['number','Número','123', true, false],
                        ['complement','Complemento','Apto, Bloco, etc. (opcional)', false, false],
                        ['neighborhood','Bairro','Seu bairro', true, true],
                        ['city','Cidade','Sua cidade', false, true],
                        ['state','Estado','Estado', false, true],
                    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$name, $label, $placeholder, $required, $cepDisabled]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="w-full">
                            <label for="<?php echo e($name); ?>" class="text-sm leading-none font-medium select-none truncate"><?php echo e($label); ?></label>
                            <input id="<?php echo e($name); ?>" name="<?php echo e($name); ?>" autocomplete="off" placeholder="<?php echo e($placeholder); ?>"
                                   value="<?php echo e(old($name)); ?>" data-cep-field
                                   <?php if($required): ?> required <?php endif; ?>
                                   <?php if($cepDisabled): ?> data-cep-fill <?php endif; ?>
                                   class="border-input text-muted-foreground placeholder:text-muted-foreground flex h-9 w-full min-w-0 rounded-sm border bg-transparent px-3 py-1 text-base shadow-none transition-[color,box-shadow] outline-none md:text-sm <?php echo e($errors->has($name) ? 'border-red-500' : ''); ?>">
                            <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="flex items-center px-6">
                <button type="submit" data-submit
                        class="text-foreground h-12 cursor-pointer rounded-none bg-[#FDC900] px-4 text-base shadow-none hover:shadow-[inset_0_-2px_0_0_#E9B425] disabled:cursor-not-allowed disabled:opacity-50">Continuar</button>
            </div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\Users\brami\Github\uol-mail\resources\views\billing\index.blade.php ENDPATH**/ ?>