<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title' => 'UOL E-mail']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title' => 'UOL E-mail']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if (isset($component)) { $__componentOriginale36aa390214cc3ce03320cafb6103431 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale36aa390214cc3ce03320cafb6103431 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.document','data' => ['title' => $title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.document'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?>
    <div style="background: none repeat scroll 0 0 #e5e9ec">
        <div class="bg-background mx-auto flex min-h-screen max-w-[94rem] flex-col shadow-xl">
            <header class="flex h-12 w-full items-center justify-around bg-[#262626] px-10 shadow-xl">
                <img src="<?php echo e(asset('logo_completo_white.svg')); ?>" alt="UOL" class="h-6">
                <div class="hidden items-center gap-8 md:flex">
                    <p class="flex flex-wrap items-center justify-center gap-2 text-sm text-white">
                        <a href="#">INGRESSO.COM</a><a href="#">UOL HOST</a><a href="#">PAGBANK</a>
                        <a href="#">CURSOS</a><a href="#">UOL PLAY</a><a href="#">UOL ADS</a>
                    </p>
                    <nav><ul class="flex items-center justify-center gap-4 text-sm text-white">
                        <li><a href="#">BUSCA</a></li><li><a href="#">BATE-PAPO</a></li><li><a href="#">EMAIL</a></li>
                    </ul></nav>
                </div>
            </header>
            <main class="container mx-auto grow py-20"><div class="mx-auto max-w-screen-lg flex-1"><?php echo e($slot); ?></div></main>
            <footer class="mt-auto w-full border-t-2 py-4 text-center text-xs text-gray-700">
                <p>Sua senha é secreta. Nenhum funcionário a serviço do UOL está autorizado a solicitá-la.</p>
                <ul class="flex flex-wrap items-center justify-center gap-1">
                    <li><a class="text-blue-500" href="#">Regras de uso</a></li>
                    <li><span class="bg-foreground min-h-4 inline-block w-px"></span></li>
                    <li><a class="text-blue-500" href="#">Política anti-spam</a></li>
                    <li><span class="bg-foreground min-h-4 inline-block w-px"></span></li>
                    <li><a class="text-blue-500" href="#">Crimes virtuais: denuncie</a></li>
                    <li><span class="bg-foreground min-h-4 inline-block w-px"></span></li>
                    <li><a class="text-blue-500" href="#">Normas de Segurança e privacidade</a></li>
                </ul>
                <p>© 1996 - 2025 - UOL - O melhor conteúdo. Todos os direitos reservados.</p>
                <p>UNIVERSO ONLINE S/A - CNPJ/MF 01.109.184/0001-95 - Av. Brigadeiro Faria Lima, 1.384, São Paulo/SP - CEP 01452-002 - uol.com.br/sac</p>
            </footer>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale36aa390214cc3ce03320cafb6103431)): ?>
<?php $attributes = $__attributesOriginale36aa390214cc3ce03320cafb6103431; ?>
<?php unset($__attributesOriginale36aa390214cc3ce03320cafb6103431); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale36aa390214cc3ce03320cafb6103431)): ?>
<?php $component = $__componentOriginale36aa390214cc3ce03320cafb6103431; ?>
<?php unset($__componentOriginale36aa390214cc3ce03320cafb6103431); ?>
<?php endif; ?>
<?php /**PATH C:\Users\brami\Github\uol-mail\resources\views\components\layouts\app.blade.php ENDPATH**/ ?>