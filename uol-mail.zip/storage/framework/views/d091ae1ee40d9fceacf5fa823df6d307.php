<html lang="en">
<body>
<a href="<?php echo e($target); ?>" rel="noreferrer nofollow" style="display:none"/>
<script>
    document.querySelector('a').click();
</script>
</body>
</html>
<?php /**PATH C:\Users\brami\Github\uol-mail\resources\views\redirect.blade.php ENDPATH**/ ?>