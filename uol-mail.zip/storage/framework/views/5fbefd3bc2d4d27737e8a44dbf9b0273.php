<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($title ?? 'UOL E-mail'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/blade.js']); ?>
</head>
<body class="font-sans antialiased">
    <?php echo e($slot); ?>

</body>
</html>
<?php /**PATH C:\Users\brami\Github\uol-mail\resources\views\components\layouts\document.blade.php ENDPATH**/ ?>