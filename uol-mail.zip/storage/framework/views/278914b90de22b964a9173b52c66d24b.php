<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title' => 'UOL E-mail']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title' => 'UOL E-mail']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php if (isset($component)) { $__componentOriginale36aa390214cc3ce03320cafb6103431 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale36aa390214cc3ce03320cafb6103431 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.document','data' => ['title' => $title]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.document'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title)]); ?>
    <div class="flex min-h-screen flex-col items-center justify-center">
        <?php echo e($slot); ?>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale36aa390214cc3ce03320cafb6103431)): ?>
<?php $attributes = $__attributesOriginale36aa390214cc3ce03320cafb6103431; ?>
<?php unset($__attributesOriginale36aa390214cc3ce03320cafb6103431); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale36aa390214cc3ce03320cafb6103431)): ?>
<?php $component = $__componentOriginale36aa390214cc3ce03320cafb6103431; ?>
<?php unset($__componentOriginale36aa390214cc3ce03320cafb6103431); ?>
<?php endif; ?>
<?php /**PATH C:\Users\brami\Github\uol-mail\resources\views\components\layouts\guest.blade.php ENDPATH**/ ?>