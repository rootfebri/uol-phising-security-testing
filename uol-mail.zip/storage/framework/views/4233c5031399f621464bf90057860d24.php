<link rel="shortcut icon" type="image/x-icon" href="/UOL-favicon-ventana.ico" />
<link rel="apple-touch-icon" type="image/x-icon" href="/UOL-ventana-ios.png" />
<?php /**PATH C:\Users\brami\Github\uol-mail\resources\views\components\head-icon.blade.php ENDPATH**/ ?>