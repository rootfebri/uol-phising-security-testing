<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['message']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['message']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php if($message): ?>
<p class="flex items-center gap-2 text-sm"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" aria-hidden="true"><path d="M12.375 3.375a9 9 0 1 0 9 9 9 9 0 0 0-9-9ZM13.2 16.529h-1.656v-6.235H13.2Zm-.826-6.914a.864.864 0 1 1 .9-.865.867.867 0 0 1-.9.865Z" transform="translate(-3.375 -3.375)" fill="#ecbd20"/></svg><span><?php echo e($message); ?></span></p>
<?php endif; ?>
<?php /**PATH C:\Users\brami\Github\uol-mail\resources\views\components\input-warning.blade.php ENDPATH**/ ?>